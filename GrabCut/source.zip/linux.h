#ifndef LINUX_H
#define LINUX_H

#include <random>
#include <time.h>

namespace library
{
	double random()
	{
		static std::random_device device;
		static std::uniform_real_distribution<double> distribution(0.0, 1.0);

		return distribution(device);
	};
};

#endif